function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(135,206,235);
  fill(80,180,80);
  rect(0,320,400,80);

  drawTree(80,100);
  drawTree(200,140);
  drawTree(320,80);

  drawFlower(50,350);
  drawFlower(150,360);
  drawFlower(260,355);
}

function getH(s) {
  return s*0.8;
}

function drawTree(x,s) {
  let h=getH(s);
  fill(110,70,30);
  rect(x-10,330-h,20,h);
  fill(34,139,34);
  ellipse(x,330-h,s,s);
  
}

function drawFlower(x,y) {
  fill(255,0,100);
  ellipse(x,y,20,20);
}